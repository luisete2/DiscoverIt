# Changelog

## v2.0.1 - 2014-01-25
- Patch: Implement banner in minified css and uglified javascript

## v2.0.0 - 2014-01-21
- Breaking change: rename actual plugin to .tabs() instead of .form5Tabs() because it makes a lot more sense.

## v1.0.1 - 2014-01-14
- Bug fix: toggle() now returns newly activated tab element as expected

## v1.0.0 - 2014-01-13
- Initial release
