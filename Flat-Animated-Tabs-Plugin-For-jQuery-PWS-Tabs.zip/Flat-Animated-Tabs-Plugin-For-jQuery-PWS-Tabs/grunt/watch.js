module.exports = {
  
    css: {
        files: 'assets/sass/*.scss',
        tasks: ['sass', 'autoprefixer']
    }
    
};