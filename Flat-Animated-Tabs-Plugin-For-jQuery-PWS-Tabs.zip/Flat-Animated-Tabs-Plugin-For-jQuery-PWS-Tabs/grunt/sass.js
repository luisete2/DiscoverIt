module.exports = {
    
    dist: {
        options: {
            style: 'expanded',
            debugInfo: false
        },
        files: {
            'assets/jquery.pwstabs.css': 'assets/sass/jquery.pwstabs.scss'
        }
    }
    
};